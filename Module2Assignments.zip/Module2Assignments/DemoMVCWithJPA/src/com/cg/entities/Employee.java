package com.cg.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Employee")
public class Employee {
@Id
@Column(name="empno")
@NotNull(message="Empno is mandatory")
private Integer empno;

@Column(name="empname")
@NotEmpty(message="Name is mandatory")
@Pattern(regexp="[A-Za-z]{3,15}",message="name should contain min 3 max 15 letters")
private String empname;

@Column(name="age")
@NotNull(message="Age is mandatory")
private Integer age;



public Integer getEmpno() {
	return empno;
}

public void setEmpno(Integer empno) {
	this.empno = empno;
}

public String getEmpname() {
	return empname;
}

public void setEmpname(String empname) {
	this.empname = empname;
}

public Integer getAge() {
	return age;
}

public void setAge(Integer age) {
	this.age = age;
}

@Override
public String toString() {
	return "Employee [empno=" + empno + ", empname=" + empname + ", age=" + age
			+ "]";
}

public Employee(Integer empno, String empname, Integer age) {
	super();
	this.empno = empno;
	this.empname = empname;
	this.age = age;
}

public Employee() {
}




}
