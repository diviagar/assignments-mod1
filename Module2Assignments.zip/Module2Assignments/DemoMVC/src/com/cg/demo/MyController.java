package com.cg.demo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.ModelAndView;

public class MyController implements Controller{
@Override
public ModelAndView handleRequest(HttpServletRequest arg0,HttpServletResponse arg1) throws Exception
{
	String message="Welcome to spring mvc";
	return new ModelAndView("Hello","message",message);
	//first argument is name of view second argument is name of model and third is value of model which is data
	
}

}
