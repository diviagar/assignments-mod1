package com.cg.cookies;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StatusServlet
 */
@WebServlet("/StatusServlet")
public class StatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StatusServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	Cookie[] carr=request.getCookies();
	PrintWriter out=response.getWriter();
	boolean flag=false;
	if(carr!=null)
	{
		for(Cookie c:carr)
		{
			if(c.getName().equals("userName"));
			{
				out.println("<html><body>");
				out.println("<h2>Hello...."+c.getValue());
				out.println("Below are the order details");
				out.println("</body></html>");
				flag=true;
			}
		}
	
	if(!flag)
		{
		response.sendRedirect("Welcome.html");
		
		}}
	else
		response.sendRedirect("Welcome.html");
	
	}

}
