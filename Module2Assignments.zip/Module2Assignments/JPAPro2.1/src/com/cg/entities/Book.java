package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Book")

public class Book {
@Id
@Column(name="isbn")
private int isbn;
@Column(name="title")
String title;
@Column(name="price")
private float price;

public Book() {
	
}
public Book(int isbn, String title, float price) {
	super();
	this.isbn = isbn;
	this.title = title;
	this.price = price;
}
public int getIsbn() {
	return isbn;
}
public void setIsbn(int isbn) {
	this.isbn = isbn;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
@Override
public String toString() {
	return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
}


}
