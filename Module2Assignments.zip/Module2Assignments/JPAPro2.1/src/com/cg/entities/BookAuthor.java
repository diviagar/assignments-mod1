package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="book_author")

public class BookAuthor {
@Id
@Column(name="book")
private String book;
@Column(name="author")
private String author;
public BookAuthor(String book, String author) {
	super();
	this.book = book;
	this.author = author;
}
public BookAuthor() {
	super();
	// TODO Auto-generated constructor stub
}
public String getBook() {
	return book;
}
public void setBook(String book) {
	this.book = book;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
@Override
public String toString() {
	return "BookAuthor [book=" + book + ", author=" + author + "]";
}


}
