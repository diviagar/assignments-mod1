package com.cg.ui;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entities.AuthorDetails;
import com.cg.entities.Book;


public class BookMain {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter choice 1.All books/n 2.Books by suthor name\n 3.UPDATE PNO \n 4. To display all details");

	    int n=sc.nextInt();
		switch(n)
		{

		case 1:
	System.out.println("Boks in DB");

	TypedQuery<Book> query1=em.createQuery("select b from Book b",Book.class);
    List<Book> blist1=query1.getResultList();

    for(Book m1:blist1)
          {
	System.out.println(m1);
          }
    break;
		case 2:
			System.out.println("Enter name of author");
			String aut=sc.next();
			TypedQuery<Book> query2=em.createQuery("select b from Book b, BookAuthor ba, AuthorDetails a where a.id=ba.author and b.isbn=ba.book and a.name=:auth",Book.class);
		    query2.setParameter("auth",aut);
		    List<Book> blist2=query2.getResultList();

		    for(Book m2:blist2)
		          {
			System.out.println(m2);
		          }
		    break;
		case 3:
			System.out.println("Enter min price");
			Float p1=sc.nextFloat();
			System.out.println("Enter max price");
			Float p2=sc.nextFloat();
			TypedQuery<Book> query3=em.createQuery("select b from Book b where (b.price>=:pr1 and b.price<=:pr2) ",Book.class);
		    query3.setParameter("pr1",p1);
		    query3.setParameter("pr2",p2);
		    List<Book> blist3=query3.getResultList();

		    for(Book m3:blist3)
		          {
			System.out.println(m3);
		          }
        break;
		case 4:
			System.out.println("Enter book id");
			int bid=sc.nextInt();
			TypedQuery<AuthorDetails> query4=em.createQuery("select n from AuthorDetails n, Book b,BookAuthor ba where n.id=ba.author and ba.book=b.isbn and b.isbn=:uisbn ",AuthorDetails.class);
		    query4.setParameter("uisbn",bid);
		    List<AuthorDetails> blist4=query4.getResultList();
            for(AuthorDetails m4:blist4)
		    System.out.println(m4.name);
            break;
		}
      
		}
		
	}
	
	
	
