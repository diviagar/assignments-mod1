import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import java.util.*;

import com.cg.entities.Mobile;


public class MobileQueries {
	
	public static void main(String args[])
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Scanner sc=new Scanner(System.in);
	//String jpql="select m from Mobile m where m.quantity>:qty";
	//TypedQuery<Mobile> query=em.createQuery(jpql,Mobile.class);
		TypedQuery<Mobile> query=em.createNamedQuery("getMobiles",Mobile.class);
		query.setParameter("qty", 5);
	List<Mobile> mlist=query.getResultList();
	
	for(Mobile m:mlist)
	{
		System.out.println(m);
	}
	}
}
