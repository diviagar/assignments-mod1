package com.cg.entities;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;



public class EmployeeMain {
	public static void main(String args[]){
		
	XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("demo.xml"));
  Sbu emp=(Sbu)factory.getBean("sbu");
	System.out.println(emp);
}}
