package com.cg.ui;

import java.util.ArrayList;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.util.List;

import com.cg.entities.Author;

public class AuthorMain {

	public static void main(String args[])
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
	    Scanner sc=new Scanner(System.in);
	    Author aut=new Author();
	    System.out.println("Enter choice 1.INSERT 2.REMOVE \n 3.UPDATE PNO \n 4. To display all details");
	    int n=sc.nextInt();
		switch(n)
		{

		case 1:
	System.out.println("Enter first name");
	aut.setFirstName(sc.next());
	System.out.println("Enter middle name");
	aut.setMidName(sc.next());
	System.out.println("Enter last name");
	aut.setLastName(sc.next());
	System.out.println("Enter mobile no");
	aut.setPhoneNo(sc.next());
	em.getTransaction().begin();
	em.persist(aut);
	em.getTransaction().commit();
	System.out.println("author inserted");
		
		case 2:
			System.out.println("Enter id to be deleted");
			int did=sc.nextInt();
			Author aut1=em.find(Author.class,did);
			em.getTransaction().begin();
			em.remove(aut1);
			em.getTransaction().commit();
			System.out.println("author removed");
		case 3:
			System.out.println("Enter author id to update phno");
			int pid=sc.nextInt();
			Author aut2=em.find(Author.class,pid);
			System.out.println("Enter phone no to be updated");
			aut2.setPhoneNo(sc.next());
			em.getTransaction().begin();
			em.merge(aut2);
			em.getTransaction().commit();
		case 4:
			System.out.println("Display all details of database");
			em.getTransaction().begin();
			List<Author> authorList=null;
			authorList=em.createQuery("select Author from Author Author").getResultList();
			em.getTransaction().commit();
			em.close();
			emf.close();
			if(authorList==null)
				System.out.println("Empty");
			else{
				for(Author auth:authorList)
				System.out.println("Author id="+auth.getAuthorId()+"Author first name="+auth.getFirstName()+"Author middle name="+auth.getMidName()+"Author last name="+auth.getLastName());;
			    }
				
		
			
			
		}
	}
	
	
	
}
