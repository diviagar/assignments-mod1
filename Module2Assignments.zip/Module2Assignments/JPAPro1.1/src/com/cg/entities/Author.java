package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Authors")
public class Author {
	


	@Id
	@SequenceGenerator(name="myseq",sequenceName="aut_seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@Column(name="id")
	private int authorId;

	@Column(name="firstname")
	private String firstName;

	@Column(name="middlename")
	private String midName;

	@Column(name="lastName")
	private String lastName;
	
	@Column(name="phoneno")
	private String phoneNo;

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	public Author(int authorId, String firstName, String midName,
			String lastName, String phoneNo) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.midName = midName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
	}

	public int getAuthorId() {
		return authorId;
	}



	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getMidName() {
		return midName;
	}



	public void setMidName(String midName) {
		this.midName = midName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getPhoneNo() {
		return phoneNo;
	}



	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}



	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", firstName=" + firstName
				+ ", midName=" + midName + ", lastName=" + lastName
				+ ", phoneNo=" + phoneNo + "]";
	}
	
	
	
	
	
	
	
	
	}

