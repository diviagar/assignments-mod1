package com.cg.ta.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ta.entities.Trainee;


@Repository
public class TraineeDaoImpl implements TraineeDao
{
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void insertTrainee(Trainee t) 
	{
		
		em.persist(t);
	}

	@Override
	public Trainee deleteTrainee(Integer did) 
	{
		String jpql ="SELECT t from Trainee t where traineeid=:tid";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		query.setParameter("tid",did);
		Trainee trn=query.getSingleResult();
		em.remove(trn);
		return trn;
		
	}

	@Override
	public Trainee retrieveTrainee(Integer rid) 
	{
		String jpql ="SELECT t from Trainee t where traineeid=:tid";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		query.setParameter("tid",rid);
		Trainee trn=query.getSingleResult();
		return trn;
		
	}

	@Override
	public List<Trainee> fetchAllTrainee() 
	{
		String jpql ="SELECT t from Trainee t";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}

	@Override
	public void modifyTrainee(Trainee tr)
	{
		em.merge(tr);
	}

}
