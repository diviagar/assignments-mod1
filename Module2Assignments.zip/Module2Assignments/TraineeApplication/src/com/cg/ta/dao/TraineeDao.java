package com.cg.ta.dao;

import java.util.List;

import com.cg.ta.entities.Trainee;

public interface TraineeDao {
	void insertTrainee(Trainee t);
	Trainee deleteTrainee(Integer did);
	Trainee retrieveTrainee(Integer rid);
    List<Trainee> fetchAllTrainee();
    void modifyTrainee(Trainee tr);
}
