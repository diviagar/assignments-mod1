package com.cg.ta.service;

import java.util.List;

import com.cg.ta.entities.Trainee;

public interface TraineeService {

	
	void insertTrainee(Trainee t);
	Trainee deleteTrainee(Integer did);
	Trainee retrieveTrainee(Integer rid);
    List<Trainee> fetchAllTrainee();
    void modifyTrainee(Trainee tr);
}
