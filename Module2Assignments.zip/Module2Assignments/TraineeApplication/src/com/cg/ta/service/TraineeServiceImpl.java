package com.cg.ta.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ta.dao.TraineeDao;
import com.cg.ta.entities.Trainee;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao tdao;

	@Override
	public void insertTrainee(Trainee t) 
	{
    tdao.insertTrainee(t);	
	}

	@Override
	public Trainee deleteTrainee(Integer did) 
	{
	return tdao.deleteTrainee(did);		
	}

	@Override
	public Trainee retrieveTrainee(Integer rid) 
	{
	return tdao.retrieveTrainee(rid);			
	}

	@Override
	public List<Trainee> fetchAllTrainee() 
	{
	return tdao.fetchAllTrainee();
	}

//modify the entity	
	@Override
	public void modifyTrainee(Trainee tr) 
	{
	tdao.modifyTrainee(tr);
	}

}
