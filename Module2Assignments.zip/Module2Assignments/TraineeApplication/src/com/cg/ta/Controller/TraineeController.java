package com.cg.ta.Controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ta.entities.Trainee;
import com.cg.ta.service.TraineeService;

@Controller
public class TraineeController {
static Integer SHOW_PAR_VIEW=1;
static Integer SHOW_FULL_VIEW=2;

@Autowired
TraineeService tser;


@RequestMapping("start")
public String dispHome(@RequestParam("userName") String name,@RequestParam("pass") String password,Model model)
{
	if(name.equals("ADMIN")&&password.equals("123456"))
	{
		return "Home";
	}
		else
	{
		return "index";
    }
}


//Add User
@RequestMapping("add")
public String addTrainee(@ModelAttribute("tdetails")Trainee tdetails,Model model)
{
	model.addAttribute("tdetails",tdetails);
	return "adddetails";
}
	
@RequestMapping("adddetails")
public String insertTrainee(@Valid @ModelAttribute("tdetails")Trainee tdetails ,
	BindingResult res, Model model)
{
	if(res.hasErrors())
	{
	model.addAttribute("tdetails",tdetails);
	return "adddetails";
	}
	else
	{
	tser.insertTrainee(tdetails);
	model.addAttribute("tdetails",tdetails);
	return "Home";
	}
}



//Delete User
@RequestMapping("delete")
public String delTrainee(@ModelAttribute("trainee")Trainee trainee,Model model)
{
	model.addAttribute("view_mode",SHOW_PAR_VIEW);
	model.addAttribute("trainee",trainee);
	return "deletetrainee";
}
	 
@RequestMapping("deletetrainee")
public String showTrainee(@Valid @ModelAttribute("traineeId")Integer traineeId ,
	BindingResult res, Model model)
{
	model.addAttribute("view_mode",SHOW_FULL_VIEW);
	Trainee trainee=tser.retrieveTrainee(traineeId);
	model.addAttribute("trainee",trainee);
	return "deletetrainee";
}
	
@RequestMapping("deletenew")
public String deleteTrainee(@Valid @ModelAttribute("trainee")Trainee trainee ,
	BindingResult res, Model model)
{
    model.addAttribute("trainee",trainee);
	tser.deleteTrainee(trainee.getTraineeId());
	return "Home";
}
	
	
	
//Retrieve 	User
@RequestMapping("retrieve")
public String retrieveOneTrainee(@ModelAttribute("trainee")Trainee trainee,Model model)
{   
	model.addAttribute("view_mode",SHOW_PAR_VIEW);
	model.addAttribute("trainee",trainee);
	return "RetrieveOneTrainee";
}

@RequestMapping("RetrieveOne")
public String retrieveTrainee(@ModelAttribute("trainee")Trainee trainee,Model model,
	BindingResult res)
{   
	model.addAttribute("view_mode",SHOW_FULL_VIEW);
	Trainee traineeObj=tser.retrieveTrainee(trainee.getTraineeId());
	model.addAttribute("traineeObj",traineeObj);
	return "RetrieveOneTrainee";
}
	
@RequestMapping("retrieveall")
public String fetchAllTrainee(Model model)
{
	List<Trainee> tlist=tser.fetchAllTrainee();
	model.addAttribute("tlist",tlist);
	return "retrievealltrainee";
}
	



//Modify User
@RequestMapping("modify")
public String changeTrainee(@ModelAttribute("trainee")Trainee trainee ,
	 Model model)
{
	model.addAttribute("view_mode",SHOW_PAR_VIEW);
	model.addAttribute("trainee",trainee);
	return "ModifyTrainee";
}
@RequestMapping("modify1")
public String changeTrainee1(@ModelAttribute("trainee")Trainee trainee ,
		Model model)
{
	model.addAttribute("view_mode",SHOW_FULL_VIEW);
	trainee = tser.retrieveTrainee(trainee.getTraineeId());
	model.addAttribute("trainee",trainee);
	return "ModifyTrainee";
}

@RequestMapping("modifytr")
public String modifyTrainee(@Valid @ModelAttribute("trainee")Trainee trainee ,
    BindingResult br, Model model)
{
	tser.modifyTrainee(trainee);
	return "Home";
}



}
	