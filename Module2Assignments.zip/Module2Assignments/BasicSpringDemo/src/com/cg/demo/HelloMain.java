package com.cg.demo;


import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class HelloMain {
public static void main(String args[])
{

	//XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("demo.xml"));
ClassPathXmlApplicationContext factory=new ClassPathXmlApplicationContext("demo.xml");

	//HelloBean bean=(HelloBean)factory.getBean("hBean");
	//System.out.println(bean.helloWorld());
	
	//Address myAdd=(Address)factory.getBean("address");//id or class name both can be used
	//System.out.println(myAdd);
Employee emp=factory.getBean(Employee.class);//no need to do type cast because it is getting matched with bean
//wiring is relation between one object to another object
System.out.println(emp);

}
}
