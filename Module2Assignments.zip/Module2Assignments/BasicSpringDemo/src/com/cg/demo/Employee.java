package com.cg.demo;

import java.util.List;

public class Employee {
private int empid;
private String ename;
private List<Address> addlist;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public List<Address> getAddlist() {
	return addlist;
}
public void setAddlist(List<Address> addlist) {
	this.addlist = addlist;
}
@Override
public String toString() {
	return "Employee [empid=" + empid + ", ename=" + ename + ", addlist="
			+ addlist + "]";
}




}
